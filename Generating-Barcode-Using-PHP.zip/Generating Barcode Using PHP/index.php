<html>
<head>
	<title>PHP Barcode Generator</title>
</head>
<body>
<fieldset>
	<legend>Detail Informations</legend>
		<form action="createbarcode.php" method="post"> <!-- Create Post method to createbarcode.php files -->
			<b>Enter Your Code </b><input type="text" name="barcode"/><input type="submit" value="Create Barcode" />
		</form>
</fieldset>
</body>
</html>