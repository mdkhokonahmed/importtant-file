/*
	CyberHost Theme Scripts
*/

(function($){ "use strict";
             
    $(window).on('load', function() {
        $('body').addClass('loaded');
    });

/*=========================================================================
    Mobile Menu
=========================================================================*/  
    $(function(){
        $('.nav-menu').slicknav({
            prependTo: '.mobile-menu',
            label: '',
            allowParentLinks: true
        });
    });

/*=========================================================================
    Main Slider
=========================================================================*/
    var owlSlider = $('#main-slider');
    owlSlider.owlCarousel({
        items: 1,
        loop: true,
        smartSpeed: 500,
        autoplayTimeout: 3500,
        autoplay: false,
        nav: true,
        navText: ['<i class="arrow_carrot-left"></i>', '<i class="arrow_carrot-right"></i>']
    });
    // Slider animation
    owlSlider.on('translate.owl.carousel', function () {
        $('.slider_content h1, .slider_content .list, .slider_content p, .slider_content a.white_btn').removeClass('fadeInUp animated').hide();
        $('.slider_item .right_img').removeClass('slideInRight animated').hide();
    });

    owlSlider.on('translated.owl.carousel', function () {
        $('.slider_content h1, .slider_content .list, .slider_content p, .slider_content a.white_btn').addClass('fadeInUp animated').show();
        $('.slider_item .right_img').addClass('slideInRight animated').show();
    });


/*=========================================================================
	Accordion Script
=========================================================================*/
	if ($('.accordion-box').length) {
	    $('.accordion-box .acc-heading').on( 'click', function() {
	        if ($(this).hasClass('active') !== true) {
	            $('.accordion-box .acc-heading').removeClass('active');
	        }

	        if ($(this).next('.acc-content').is(':visible')) {
	            $(this).removeClass('active');
	            $(this).next('.acc-content').slideUp(500);
	        } else {
	            $(this).addClass('active');
	            $('.accordion-box .acc-content').slideUp(500);
	            $(this).next('.acc-content').slideDown(500);
	        }
	    });
	}
/*=========================================================================
    Sponsor Carousel
=========================================================================*/
	$('#sponsor_carousel').owlCarousel({
        loop: true,
        margin: 10,
        autoplay: true,
        smartSpeed: 1000,
        nav: false,
        dots: false,
        responsive: true,
        responsive : {
		    0 : {
		        items: 3
		    },
		    480 : {
		        items: 3,
		    },
		    768 : {
		        items: 5,
		    }
		}
    });
					 
/*=========================================================================
	Initialize smoothscroll plugin
=========================================================================*/
	smoothScroll.init({
		offset: 60
	});

/*=========================================================================
	Active venobox
=========================================================================*/
	var vbSelector = $('.img_popup');
	vbSelector.venobox({
		numeratio: true,
		infinigall: true
	});    
				 
/*=========================================================================
	Scroll To Top
=========================================================================*/ 
    $(window).on( 'scroll', function () {
        if ($(this).scrollTop() > 100) {
            $('#scroll-to-top').fadeIn();
        } else {
            $('#scroll-to-top').fadeOut();
        }
    });

})(jQuery);
