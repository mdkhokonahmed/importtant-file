from django.db import models

# Create your models here.


class Allservice(models.Model):
	STATUS_CHOICES = (
		('P', 'Published'),
		('U', 'Unpublished'),
		)
	title = models.CharField(max_length=100)
	bodytext = models.TextField()
	image = models.ImageField()
	status = models.CharField(max_length=1, choices=STATUS_CHOICES)



# PEOPLE SAYS MANAGE

class Pepolemanage(models.Model):
	STATUS_CHOICES = (
		('P', 'Published'),
		('U', 'Unpublished'),
		)
	pepolename = models.CharField(max_length=50)
	description = models.CharField(max_length=255)
	image = models.ImageField()
	status = models.CharField(max_length=1, choices=STATUS_CHOICES)

class Blogpostmanage(models.Model):
	title = models.CharField(max_length=100)
	name  = models.CharField(max_length=50)
	description = models.TextField()
	image = models.ImageField()
	date = models.DateField(null=True, blank=True)

class Aboutcontent(models.Model):
	title = models.CharField(max_length=100)
	description = models.TextField()
	image = models.ImageField()
	
class Addresscontact(models.Model):
	cellnumber = models.CharField(max_length=20)
	emailaddress = models.CharField(max_length=255)
	address = models.CharField(max_length=255)

class Contactoption(models.Model):
	name = models.CharField(max_length=100)
	emailaddress = models.CharField(max_length=200)
	message = models.TextField()
	
		


	
		
	
		
	
		

	
	
		
	
		