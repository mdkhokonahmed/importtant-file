from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import redirect
from .models import Allservice,Pepolemanage,Blogpostmanage,Aboutcontent,Addresscontact,Contactoption
# Create your views here.

def home(request):
	all_services = Allservice.objects.all().order_by('-id')[:6]
	all_pepoles = Pepolemanage.objects.all().order_by('-id')[:3]
	all_blogposts = Blogpostmanage.objects.all().order_by('-id')[:3]
	return render(request, 'home.html', {'all_services':all_services, 'all_pepoles':all_pepoles, 'all_blogposts':all_blogposts})

def about(request):
	all_pepoles = Pepolemanage.objects.all().order_by('-id')[:3]
	all_aboutcontent = Aboutcontent.objects.all().order_by('-id')[:1]
	return render(request, 'about.html',{'all_pepoles':all_pepoles, 'all_aboutcontent':all_aboutcontent})

def service(request):
	all_services = Allservice.objects.all().order_by('-id')[:6]
	return render(request, 'service.html',{'all_services':all_services})

def domain(request):
	return render(request, 'domain.html')

def contact(request):
	address_content = Addresscontact.objects.all()
	return render(request, 'contact.html',{'address_content':address_content})
def savecontact(request):
	if request.method == 'POST':
		name = request.POST.get("name","")
		emailaddress = request.POST.get("emailaddress","")
		message = request.POST.get("message","")
	if name == '' and emailaddress == '' and message == '':
		return HttpResponse('Field must be empty')
		return redirect('contact')
	else:
		data = Contactoption(name=name, emailaddress=emailaddress, message=message)
		data.save()
		return HttpResponse('Welcome')

	return redirect('contact')
		

	