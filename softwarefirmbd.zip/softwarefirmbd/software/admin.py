from django.contrib import admin
from .models import Allservice,Pepolemanage,Blogpostmanage,Aboutcontent,Addresscontact,Contactoption

# Register your models here.
class AllserviceAdmin(admin.ModelAdmin):
	search_fields = ['title','bodytext', 'status']
	list_filter = ['title','bodytext', 'status']
	list_display = ['title','bodytext', 'status']
	pass

admin.site.register(Allservice, AllserviceAdmin)

class PepolemanageAdmin(admin.ModelAdmin):
	search_fields = ['pepolename', 'description', 'status']
	list_display = ['pepolename', 'description', 'status']
	pass

admin.site.register(Pepolemanage, PepolemanageAdmin)

class BlogpostmanageAdmin(admin.ModelAdmin):
	search_fields = ['title', 'name', 'description']
	list_display = ['title', 'name', 'description', 'image', 'date']
	pass

admin.site.register(Blogpostmanage, BlogpostmanageAdmin)

class AboutcontentAdmin(admin.ModelAdmin):
	search_fields = ['title', 'description']
	list_display = ['title',  'description', 'image']
	pass
admin.site.register(Aboutcontent, AboutcontentAdmin)

class AddresscontactAdmin(admin.ModelAdmin):
	search_fields = ['cellnumber', 'emailaddress', 'address']
	list_display = ['cellnumber', 'emailaddress', 'address']
	pass
admin.site.register(Addresscontact, AddresscontactAdmin)

class ContactoptionAdmin(admin.ModelAdmin):
	search_fields = ['name', 'emailaddress', 'message']
	list_display = ['name', 'emailaddress', 'message']
	pass
admin.site.register(Contactoption, ContactoptionAdmin)

